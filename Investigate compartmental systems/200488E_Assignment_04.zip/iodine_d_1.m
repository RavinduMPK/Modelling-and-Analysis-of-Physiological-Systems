function yp = iodine_d(t,y);
yp = [-2.52 0 .08;.84 -.2 0;0 .2 -.1]*y + [150 0 0]';