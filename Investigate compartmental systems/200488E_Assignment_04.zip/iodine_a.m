function yp = iodine_a(t,y);
yp = [-2.52 0 .08;.84 -.005 0;0 .005 -.1]*y + [150 0 0]';