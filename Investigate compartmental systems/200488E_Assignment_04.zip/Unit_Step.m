function yp = Unit_Step(t,y)
yp = [-0.8 0.2;-5 -2]*y + [0 1]';
