function yp = iodine_b(t,y);
yp = [-2.52 0 .08;.84 -.01 0;0 .01 -.1]*y + [50 0 0]';